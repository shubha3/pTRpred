from __future__ import annotations

from dataclasses import dataclass
from typing import List, Literal

import numpy as np
import pybamm


ModelName = Literal["spm", "dfn"]


@dataclass
class PyBaMMReferenceResult:
    """Time-aligned arrays from a single-cell PyBaMM solve."""

    t_s: np.ndarray
    T_cell_K: np.ndarray
    Q_total_W: np.ndarray
    V_V: np.ndarray
    model: str
    thermal_option: str


def _solution_to_aligned_arrays(sol: pybamm.Solution) -> tuple[np.ndarray, ...]:
    t_s = np.asarray(sol["Time [s]"].entries, dtype=np.float64).ravel()
    T_cell_K = np.asarray(sol["Cell temperature [K]"].entries, dtype=np.float64).ravel()
    Q_total_W = np.asarray(sol["Total heating [W]"].entries, dtype=np.float64).ravel()
    V_V = np.asarray(sol["Terminal voltage [V]"].entries, dtype=np.float64).ravel()
    n = min(t_s.size, T_cell_K.size, Q_total_W.size, V_V.size)
    return (
        t_s[:n],
        T_cell_K[:n],
        Q_total_W[:n],
        V_V[:n],
    )


def _resample_uniform(
    t_raw: np.ndarray,
    T_K: np.ndarray,
    Q_W: np.ndarray,
    V_V: np.ndarray,
    n_time: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Linear interpolation onto ``n_time`` points from 0 to ``t_raw[-1]``."""
    if t_raw.size < 2:
        raise ValueError("need at least 2 time samples to resample")
    t_final = float(t_raw[-1])
    if t_final <= 0.0:
        raise ValueError("non-positive simulation horizon")
    t_new = np.linspace(0.0, t_final, int(n_time))
    return (
        t_new,
        np.interp(t_new, t_raw, T_K),
        np.interp(t_new, t_raw, Q_W),
        np.interp(t_new, t_raw, V_V),
    )


def build_cycle_experiment_strings(
    n_cycles: int,
    I_discharge_A: float,
    I_charge_A: float,
    t_discharge_s: float,
    t_charge_s: float,
    *,
    t_rest_after_discharge_s: float = 0.0,
    t_rest_after_charge_s: float = 0.0,
    V_min_V: float = 3.2,
    V_max_V: float = 4.1,
) -> List[str]:
    """
    Build PyBaMM ``Experiment`` protocol strings.

    Uses voltage-guarded timed steps:
    - Discharge at I for t seconds OR until V_min
    - Charge at I for t seconds OR until V_max

    This is much more stable for multi-cycle generation than pure fixed-time steps.
    """
    if n_cycles < 1:
        raise ValueError("n_cycles must be >= 1")
    if V_min_V <= 0 or V_max_V <= 0 or V_min_V >= V_max_V:
        raise ValueError("Require 0 < V_min_V < V_max_V")

    steps: List[str] = []
    for _ in range(int(n_cycles)):
        steps.append(
            f"Discharge at {float(I_discharge_A)} A for {float(t_discharge_s)} seconds or until {float(V_min_V)} V"
        )
        if t_rest_after_discharge_s > 0.0:
            steps.append(f"Rest for {float(t_rest_after_discharge_s)} seconds")

        steps.append(
            f"Charge at {float(I_charge_A)} A for {float(t_charge_s)} seconds or until {float(V_max_V)} V"
        )
        if t_rest_after_charge_s > 0.0:
            steps.append(f"Rest for {float(t_rest_after_charge_s)} seconds")

    return steps


def run_pybamm_reference_cycles(
    n_cycles: int,
    n_time: int = 601,
    I_discharge_A: float = 4.0,
    I_charge_A: float = 2.0,
    t_discharge_s: float = 150.0,
    t_charge_s: float = 150.0,
    *,
    t_rest_after_discharge_s: float = 120.0,
    t_rest_after_charge_s: float = 120.0,
    V_min_V: float = 3.2,
    V_max_V: float = 4.1,
    model: ModelName = "spm",
    thermal: str = "lumped",
    ambient_temp_C: float = 25.0,
) -> PyBaMMReferenceResult:
    """
    Repeated discharge / rest / charge / rest using ``pybamm.Experiment``.
    Output is resampled to ``n_time`` uniformly spaced times over the solved horizon.

    The cycle steps are voltage-guarded, which helps avoid infeasible multi-cycle runs.
    """
    opts = {"thermal": thermal}
    if model == "spm":
        m = pybamm.lithium_ion.SPM(options=opts)
    elif model == "dfn":
        m = pybamm.lithium_ion.DFN(options=opts)
    else:
        raise ValueError(f"model must be 'spm' or 'dfn', got {model!r}")

    protocol = build_cycle_experiment_strings(
        n_cycles=n_cycles,
        I_discharge_A=I_discharge_A,
        I_charge_A=I_charge_A,
        t_discharge_s=t_discharge_s,
        t_charge_s=t_charge_s,
        t_rest_after_discharge_s=t_rest_after_discharge_s,
        t_rest_after_charge_s=t_rest_after_charge_s,
        V_min_V=V_min_V,
        V_max_V=V_max_V,
    )

    experiment = pybamm.Experiment(protocol)
    param = m.default_parameter_values.copy()
    param["Ambient temperature [C]"] = ambient_temp_C

    sim = pybamm.Simulation(m, parameter_values=param, experiment=experiment)
    sim.solve()

    t_raw, T_raw, Q_raw, V_raw = _solution_to_aligned_arrays(sim.solution)
    t_s, T_cell_K, Q_total_W, V_V = _resample_uniform(
        t_raw, T_raw, Q_raw, V_raw, n_time
    )
    return PyBaMMReferenceResult(
        t_s=t_s,
        T_cell_K=T_cell_K,
        Q_total_W=Q_total_W,
        V_V=V_V,
        model=model,
        thermal_option=thermal,
    )


def run_pybamm_reference(
    t_end_s: float = 3600.0,
    n_time: int = 601,
    I_cell_A: float = 2.0,
    *,
    model: ModelName = "spm",
    thermal: str = "lumped",
    ambient_temp_C: float = 25.0,
) -> PyBaMMReferenceResult:
    """
    Solve one representative cell with fixed current ``I_cell_A``.
    """
    opts = {"thermal": thermal}
    if model == "spm":
        m = pybamm.lithium_ion.SPM(options=opts)
    elif model == "dfn":
        m = pybamm.lithium_ion.DFN(options=opts)
    else:
        raise ValueError(f"model must be 'spm' or 'dfn', got {model!r}")

    param = m.default_parameter_values.copy()
    param["Current function [A]"] = I_cell_A
    param["Ambient temperature [C]"] = ambient_temp_C

    sim = pybamm.Simulation(m, parameter_values=param)
    t_eval = np.linspace(0.0, float(t_end_s), int(n_time))
    sim.solve(t_eval=t_eval)

    t_raw, T_raw, Q_raw, V_raw = _solution_to_aligned_arrays(sim.solution)
    t_s, T_cell_K, Q_total_W, V_V = _resample_uniform(
        t_raw, T_raw, Q_raw, V_raw, n_time
    )
    return PyBaMMReferenceResult(
        t_s=t_s,
        T_cell_K=T_cell_K,
        Q_total_W=Q_total_W,
        V_V=V_V,
        model=model,
        thermal_option=thermal,
    )