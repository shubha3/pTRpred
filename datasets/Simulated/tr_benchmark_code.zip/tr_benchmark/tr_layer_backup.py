def tr_power_watts(T_K: np.ndarray, cfg: TRPackConfig) -> tuple[np.ndarray, np.ndarray]:
    """
    TR power [W] per cell and boolean ``active`` = (T_K > T_crit_K).

    Exponential branch (only when active):
    q_i = A_i * exp(lambda_i * (T_i - T_crit_i)).
    """
    T_K = np.asarray(T_K, dtype=np.float64)
    n = T_K.size
    if cfg.T_crit_K.shape != (n,) or cfg.A_W.shape != (n,) or cfg.lam_per_K.shape != (n,):
        raise ValueError("T_crit_K, A_W, lam_per_K must match T_K shape")
    active = T_K > cfg.T_crit_K
    q = np.zeros(n, dtype=np.float64)
    if cfg.mode == "exponential":
        dt = np.maximum(T_K - cfg.T_crit_K, 0.0)
        dt = np.minimum(dt, 80.0)   # or 50.0
        q = np.where(active, cfg.A_W * np.exp(cfg.lam_per_K * dt), 0.0)
    elif cfg.mode == "piecewise":
        q = np.where(active, cfg.Q_flat_W, 0.0)
    else:
        raise ValueError(f"unknown mode {cfg.mode!r}")

    return q, active