"""
Pack thermal network + PyBaMM electrochemical heating + TR extension (M1 coupling).

PyBaMM supplies ``Total heating [W]`` vs time for one representative cell; the same
curve (optional i.i.d. noise) drives every node. Pack temperatures evolve on a thermal graph.
References:

"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
from scipy.integrate import solve_ivp

from tr_benchmark.pybamm_layer import PyBaMMReferenceResult
from tr_benchmark.tr_layer import TRPackConfig, tr_power_watts

try:
    import networkx as nx
except ImportError:  # pragma: no cover
    nx = None  # type: ignore


@dataclass
class PackThermalParams:
    """Thermal pack: ``n_cells`` nodes on a rectangular grid unless ``edges`` is set."""

    n_cells: int = 30
    bundle_nrows: int = 5
    bundle_ncols: int = 6
    C_J_per_K: np.ndarray = field(default_factory=lambda: np.full(30, 1000.0))
    R_link_K_per_W: float = 0.05
    h_W_per_K: np.ndarray = field(default_factory=lambda: np.full(30, 0.5))
    T_amb_K: float = 298.15
    edges: List[Tuple[int, int]] = field(default_factory=list)

    def thermal_edges(self) -> List[Tuple[int, int]]:
        if self.edges:
            return list(self.edges)
        nr, nc = int(self.bundle_nrows), int(self.bundle_ncols)
        expected = nr * nc
        if int(self.n_cells) != expected:
            raise ValueError(
                f"n_cells ({self.n_cells}) must equal bundle_nrows × bundle_ncols "
                f"({nr}×{nc}={expected}) when using the default grid; "
                "set matching dimensions or pass explicit edges=... for a custom graph."
            )
        if nx is None:
            raise ImportError("networkx is required for the default rectangular grid")
        G = nx.convert_node_labels_to_integers(
            nx.grid_2d_graph(nr, nc), first_label=0
        )
        return list(G.edges())


@dataclass
class CoupledPackResult:
    t_s: np.ndarray
    T_pack_K: np.ndarray
    Q_echem_W: np.ndarray
    Q_tr_W: np.ndarray
    triggered: np.ndarray
    meta: Dict[str, Any]


def _neighbor_heat_flux_W(T: np.ndarray, edges: List[Tuple[int, int]], inv_R: float) -> np.ndarray:
    """Sum_j (T_j - T_i) / R on each node i."""
    n = T.size
    q = np.zeros(n, dtype=np.float64)
    for a, b in edges:
        q[a] += (T[b] - T[a]) * inv_R
        q[b] += (T[a] - T[b]) * inv_R
    return q


def neighbor_temperature_features(
    T_pack_K: np.ndarray,
    edges: List[Tuple[int, int]],
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Graph-neighbor temperature statistics per cell and time (same shape as ``T_pack_K``).

    For each node, neighbors are endpoints of edges incident on that node (thermal graph).
    Cells with no neighbors fall back to self temperature for mean/min/max and std = 0.
    """
    T = np.asarray(T_pack_K, dtype=np.float64)
    if T.ndim != 2:
        raise ValueError(f"T_pack_K must be 2D (n_t, n_cells), got {T.shape}")
    nt, n = T.shape
    nbr: List[List[int]] = [[] for _ in range(n)]
    for a, b in edges:
        nbr[a].append(b)
        nbr[b].append(a)
    mean_K = np.zeros((nt, n), dtype=np.float64)
    min_K = np.zeros((nt, n), dtype=np.float64)
    max_K = np.zeros((nt, n), dtype=np.float64)
    std_K = np.zeros((nt, n), dtype=np.float64)
    for i in range(n):
        js = nbr[i]
        self_col = T[:, i]
        if not js:
            mean_K[:, i] = self_col
            min_K[:, i] = self_col
            max_K[:, i] = self_col
            continue
        stack = T[:, js]
        mean_K[:, i] = stack.mean(axis=1)
        min_K[:, i] = stack.min(axis=1)
        max_K[:, i] = stack.max(axis=1)
        std_K[:, i] = stack.std(axis=1, ddof=0)
    return mean_K, min_K, max_K, std_K


def per_cell_first_trigger_times(
    t_s: np.ndarray, triggered: np.ndarray
) -> np.ndarray:
    """First time each cell satisfies ``triggered``; ``nan`` if never."""
    t = np.asarray(t_s, dtype=np.float64).ravel()
    trig = np.asarray(triggered)
    if trig.ndim == 1:
        trig = trig.reshape(-1, 1)
    _, n_c = trig.shape
    out = np.full(n_c, np.nan, dtype=np.float64)
    for c in range(n_c):
        idx = np.where(trig[:, c])[0]
        if idx.size:
            out[c] = float(t[int(idx[0])])
    return out


def per_cell_first_trigger_times(
    t_s: np.ndarray, triggered: np.ndarray
) -> np.ndarray:
    """First time each cell satisfies ``triggered``; ``nan`` if never."""
    t = np.asarray(t_s, dtype=np.float64).ravel()
    trig = np.asarray(triggered)
    if trig.ndim == 1:
        trig = trig.reshape(-1, 1)
    _, n_c = trig.shape
    out = np.full(n_c, np.nan, dtype=np.float64)
    for c in range(n_c):
        idx = np.where(trig[:, c])[0]
        if idx.size:
            out[c] = float(t[int(idx[0])])
    return out


def run_coupled_pack(
    ref: PyBaMMReferenceResult,
    thermal: PackThermalParams,
    tr_cfg: TRPackConfig,
    *,
    q_echem_noise_std_W: float = 0.0,
    seed: Optional[int] = 0,
    seed_tr_cells: Optional[List[int]] = None,
    seed_tr_delta_K: float = 55.0,
    seed_tr_floor_above_amb_K: float = 18.0,
    seed_tr_A_mult: float = 2.5,
    seed_tr_lam: float = 0.15,
    rtol: float = 1e-5,
    atol: float = 1e-7,
) -> CoupledPackResult:
    n = thermal.n_cells
    if tr_cfg.T_crit_K.size != n:
        raise ValueError("TRPackConfig arrays must have length n_cells")
    edges = thermal.thermal_edges()
    inv_C = 1.0 / np.asarray(thermal.C_J_per_K, dtype=np.float64)
    inv_R = 1.0 / float(thermal.R_link_K_per_W)
    h = np.asarray(thermal.h_W_per_K, dtype=np.float64)
    T_amb = float(thermal.T_amb_K)
    t_nodes = np.asarray(ref.t_s, dtype=np.float64)
    Q_nodes = np.asarray(ref.Q_total_W, dtype=np.float64)
    rng = np.random.default_rng(seed) if seed is not None else None
    if seed_tr_cells:
        Tcrit = np.array(tr_cfg.T_crit_K, copy=True)
        A_W = np.array(tr_cfg.A_W, copy=True)
        lam = np.array(tr_cfg.lam_per_K, copy=True)
        floor_K = T_amb + float(seed_tr_floor_above_amb_K)
        for idx in seed_tr_cells:
            j = int(idx)
            # Weaken seed vs its sampled T_crit (not ambient snap) so primary TR
            # follows charge heating, then cascade can reach neighbors.
            Tcrit[j] = max(floor_K, float(Tcrit[j]) - float(seed_tr_delta_K))
            A_W[j] = min(float(A_W[j]) * float(seed_tr_A_mult), 80.0)
            lam[j] = float(seed_tr_lam)
        tr_cfg = TRPackConfig(
            T_crit_K=Tcrit,
            A_W=A_W,
            lam_per_K=lam,
            mode=tr_cfg.mode,
            Q_flat_W=tr_cfg.Q_flat_W,
        )
    # per-cell static heterogeneity
    if rng is not None:
        q_scale = rng.lognormal(mean = 0.0, sigma = 0.15, size = n)
    else:
        q_scale = np.ones(n)
    def ode(t: float, T: np.ndarray) -> np.ndarray:
        Qb = float(np.interp(t, t_nodes, Q_nodes))
        if rng is not None and q_echem_noise_std_W > 0.0:
            Q_cell = Qb + rng.normal(0.0, q_echem_noise_std_W, size=n)
        else:
            Q_cell = np.full(n, Qb)
        Q_cell = Qb * q_scale
        q_tr, _ = tr_power_watts(T, tr_cfg)
        q_nei = _neighbor_heat_flux_W(T, edges, inv_R)
        dT = inv_C * (Q_cell + q_tr + q_nei - h * (T - T_amb))
        return dT
    T0 = np.full(n, float(ref.T_cell_K[0]))
    sol = None
    for method in ("BDF", "LSODA", "RK45"):
        sol = solve_ivp(
            ode,
            (float(t_nodes[0]), float(t_nodes[-1])),
            T0,
            t_eval=t_nodes,
            rtol=rtol,
            atol=atol,
            method=method,
        )
        if sol.success:
            break
    assert sol is not None
    if not sol.success:
        raise RuntimeError(f"solve_ivp failed ({sol.message}); try smaller --q-noise-max or rtol/atol")
    t_out = np.asarray(sol.t, dtype=np.float64)
    n_out = t_out.size
    T_pack = np.zeros((n_out, n), dtype=np.float64)
    Q_echem = np.zeros((n_out, n), dtype=np.float64)
    Q_tr = np.zeros((n_out, n), dtype=np.float64)
    Trig = np.zeros((n_out, n), dtype=bool)
    for k in range(n_out):
        t = t_out[k]
        Tk = sol.y[:, k]
        Qb = float(np.interp(t, t_nodes, Q_nodes))
        if rng is not None and q_echem_noise_std_W > 0.0:
            Qe = Qb + rng.normal(0.0, q_echem_noise_std_W, size=n)
        else:
            Qe = np.full(n, Qb)
        q_tr, active = tr_power_watts(Tk, tr_cfg)
        T_pack[k] = Tk
        Q_echem[k] = Qe
        Q_tr[k] = q_tr
        Trig[k] = active
    meta: Dict[str, Any] = {
        "pybamm_model": ref.model,
        "pybamm_thermal": ref.thermal_option,
        "n_cells": n,
        "bundle_nrows": int(thermal.bundle_nrows),
        "bundle_ncols": int(thermal.bundle_ncols),
        "n_edges": len(edges),
        "seed_tr_cells": list(seed_tr_cells or []),
        "coupling": "M1_pybamm_Q_to_pack_only",
        "solver": "scipy.solve_ivp BDF",
    }
    return CoupledPackResult(
        t_s=t_out,
        T_pack_K=T_pack,
        Q_echem_W=Q_echem,
        Q_tr_W=Q_tr,
        triggered=Trig,
        meta=meta,
    )
