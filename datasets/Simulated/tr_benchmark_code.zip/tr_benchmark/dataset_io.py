"""
Save / load multi-cell bundle trajectories for ML benchmarks.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

from tr_benchmark.pybamm_layer import PyBaMMReferenceResult
from tr_benchmark.pack_coupled import (
    CoupledPackResult,
    PackThermalParams,
    neighbor_temperature_features,
)


def save_bundle_run_npz(
    path: str | Path,
    ref: PyBaMMReferenceResult,
    pack: CoupledPackResult,
    run_id: int,
    extra_meta: Optional[Dict[str, Any]] = None,
    thermal: Optional[PackThermalParams] = None,
) -> None:
    """
    Write one simulation run. Arrays: ``t_s`` (T,), ``T_pack_K`` (T, n_cells), etc.
    Boolean ``triggered`` stored as float32 0/1.

    If ``thermal`` is passed, also writes graph-neighbor temperature features (same shape
    as ``T_pack_K``): ``T_neighbor_mean_K``, ``T_neighbor_min_K``, ``T_neighbor_max_K``,
    ``T_neighbor_std_K``, and ``dT_self_minus_neighbor_mean_K``.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    meta: Dict[str, Any] = {**pack.meta, **(extra_meta or {})}
    meta["run_id"] = int(run_id)

    n_ref = min(
        int(np.asarray(ref.t_s).size),
        int(np.asarray(ref.T_cell_K).size),
        int(np.asarray(ref.V_V).size),
        int(np.asarray(ref.Q_total_W).size),
    )
    t_ref = np.asarray(ref.t_s, dtype=np.float64).ravel()[:n_ref]
    T_ref = np.asarray(ref.T_cell_K, dtype=np.float64).ravel()[:n_ref]
    V_ref_a = np.asarray(ref.V_V, dtype=np.float64).ravel()[:n_ref]
    Q_ref_a = np.asarray(ref.Q_total_W, dtype=np.float64).ravel()[:n_ref]

    arrays = {
        "t_s": pack.t_s.astype(np.float64),
        "T_pack_K": pack.T_pack_K.astype(np.float64),
        "Q_echem_W": pack.Q_echem_W.astype(np.float64),
        "Q_tr_W": pack.Q_tr_W.astype(np.float64),
        "triggered_f": pack.triggered.astype(np.float32),
        "V_ref": np.interp(pack.t_s, t_ref, V_ref_a).astype(np.float64),
        "T_ref_K": np.interp(pack.t_s, t_ref, T_ref).astype(np.float64),
        "Q_ref_W": np.interp(pack.t_s, t_ref, Q_ref_a).astype(np.float64),
        "run_id": np.array([run_id], dtype=np.int64),
        "meta_json": np.array([json.dumps(meta, default=str)]),
    }

    if thermal is not None:
        edges = thermal.thermal_edges()
        tn_mean, tn_min, tn_max, tn_std = neighbor_temperature_features(
            pack.T_pack_K, edges
        )
        arrays["T_neighbor_mean_K"] = tn_mean.astype(np.float64)
        arrays["T_neighbor_min_K"] = tn_min.astype(np.float64)
        arrays["T_neighbor_max_K"] = tn_max.astype(np.float64)
        arrays["T_neighbor_std_K"] = tn_std.astype(np.float64)
        arrays["dT_self_minus_neighbor_mean_K"] = (
            pack.T_pack_K.astype(np.float64) - tn_mean
        )

    np.savez_compressed(path, **arrays)


def append_manifest_row(
    manifest_path: str | Path,
    fieldnames: List[str],
    row: Dict[str, Any],
) -> None:
    manifest_path = Path(manifest_path)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)
    write_header = not manifest_path.exists()
    with manifest_path.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        if write_header:
            w.writeheader()
        w.writerow(row)
