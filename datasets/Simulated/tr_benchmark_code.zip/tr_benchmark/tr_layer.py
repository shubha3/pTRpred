"""
Layer 2: phenomenological TR heat sources (not chemistry-resolved).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Union

import numpy as np

TRPreset = Literal["mild", "balanced", "aggressive", "extreme"]

_TR_PRESET_TABLE: dict[str, tuple[float, float, float]] = {
    "mild": (1.0, 0.06, 200.0),
    "balanced": (5.0, 0.12, 500.0),
    "aggressive": (28.0, 0.22, 2500.0),
    "extreme": (120.0, 0.38, 12000.0),
}


def list_tr_presets() -> tuple[str, ...]:
    return tuple(_TR_PRESET_TABLE.keys())


def tr_preset_values(preset: TRPreset) -> tuple[float, float, float]:
    if preset not in _TR_PRESET_TABLE:
        raise ValueError(f"preset must be one of {list_tr_presets()}, got {preset!r}")
    return _TR_PRESET_TABLE[preset]


@dataclass
class TRPackConfig:
    T_crit_K: np.ndarray
    A_W: np.ndarray
    lam_per_K: np.ndarray
    mode: str = "exponential"
    Q_flat_W: float = 500.0


def uniform_tr_pack_config(
    n_cells: int,
    T_crit_K: Union[float, np.ndarray],
    *,
    preset: TRPreset = "balanced",
    mode: Literal["exponential", "piecewise"] = "exponential",
    A_scale: float = 1.0,
    lam_scale: float = 1.0,
    Q_flat_scale: float = 1.0,
) -> TRPackConfig:
    n = int(n_cells)
    A0, lam0, q0 = tr_preset_values(preset)
    A = A0 * float(A_scale)
    lam = lam0 * float(lam_scale)
    q_flat = q0 * float(Q_flat_scale)
    Tc = np.asarray(T_crit_K, dtype=np.float64)
    if Tc.ndim == 0:
        Tc = np.full(n, float(Tc))
    elif Tc.size != n:
        raise ValueError(f"T_crit_K must be scalar or length {n}, got {Tc.size}")
    return TRPackConfig(
        T_crit_K=Tc,
        A_W=np.full(n, A, dtype=np.float64),
        lam_per_K=np.full(n, lam, dtype=np.float64),
        mode=str(mode),
        Q_flat_W=float(q_flat),
    )


def tr_power_watts(
    T_K: np.ndarray, cfg: TRPackConfig
) -> tuple[np.ndarray, np.ndarray]:
    T = np.asarray(T_K, dtype=np.float64).ravel()
    n = T.size
    Tc = np.asarray(cfg.T_crit_K, dtype=np.float64).ravel()
    A = np.asarray(cfg.A_W, dtype=np.float64).ravel()
    lam = np.asarray(cfg.lam_per_K, dtype=np.float64).ravel()
    if not (Tc.size == A.size == lam.size == n):
        raise ValueError("TRPackConfig array lengths must match T")
    active = T > Tc
    q = np.zeros(n, dtype=np.float64)
    if cfg.mode == "piecewise":
        q[active] = float(cfg.Q_flat_W)
    else:
        dT = np.maximum(T - Tc, 0.0)
        q[active] = A[active] * np.exp(lam[active] * dT[active])
    return q, active
