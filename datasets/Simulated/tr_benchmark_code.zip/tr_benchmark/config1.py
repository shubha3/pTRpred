#packdata config:
python3 generate_tr_pack_bundle_dataset.py  --n-runs 5 \
--out-dir data/tr_pack_bundle_stable \
--n-cycles 4 \
--model spm \
--ambient-temp-C 35 \
--I-min 3.0 \
--I-max 4.5 \
--t-dis-min 120 \
--t-dis-max 160 \
--t-ch-min 180 \
--t-ch-max 260 \
--rest-after-dis-s 120 \
--rest-after-ch-s 180 \
--seed-tr-count 1 \
--T-crit-min 330 \
--T-crit-max 345 \
--tr-preset balanced \
--tr-mode exponential


python3 visualize_tr_pack_bundle.py --data-dir data/tr_pack_bundle_safe


python3 generate_tr_pack_bundle_dataset.py  --n-runs 5 \
--out-dir data/tr_pack_bundle_mild_tr \
--n-cycles 3 \
--model spm \
--ambient-temp-C 40 \
--I-min 3.5 \
--I-max 5.5 \
--t-dis-min 120 \
--t-dis-max 180 \
--t-ch-min 200 \
--t-ch-max 320 \
--rest-after-dis-s 120 \
--rest-after-ch-s 150 \
--seed-tr-count 2 \
--T-crit-min 325 \
--T-crit-max 340 \
--tr-preset aggressive \
--tr-mode exponential

python3 visualize_tr_pack_bundle.py --data-dir data/tr_pack_bundle_mild_tr


python3 generate_tr_pack_bundle_dataset.py  --n-runs 15 \
--out-dir data/tr_pack_bundle_stress \
--n-cycles 2 \
--model spm \
--ambient-temp-C 25 \
--I-min 5.0 \
--I-max 9.5 \
--t-dis-min 100 \
--t-dis-max 140 \
--t-ch-min 120 \
--t-ch-max 180 \
--rest-after-dis-s 80 \
--rest-after-ch-s 100 \
--seed-tr-count 3 \
--T-crit-min 315 \
--T-crit-max 330 \
--tr-preset extreme \
--tr-mode exponential

python3 visualize_tr_pack_bundle.py --data-dir data/tr_pack_bundle_stress


