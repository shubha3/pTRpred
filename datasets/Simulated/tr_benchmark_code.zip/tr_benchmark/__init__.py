"""
PyBaMM + phenomenological thermal-runaway extension for pack-level benchmarks.

Requires: pybamm, numpy, scipy; networkx recommended for default 5x6 grid.
"""

from tr_benchmark.pybamm_layer import (
    PyBaMMReferenceResult,
    build_cycle_experiment_strings,
    run_pybamm_reference,
    run_pybamm_reference_cycles,
)
from tr_benchmark.tr_layer import (
    TRPackConfig,
    list_tr_presets,
    tr_power_watts,
    tr_preset_values,
    uniform_tr_pack_config,
)
from tr_benchmark.pack_coupled import (
    CoupledPackResult,
    PackThermalParams,
    neighbor_temperature_features,
    run_coupled_pack,
)

__all__ = [
    "PyBaMMReferenceResult",
    "build_cycle_experiment_strings",
    "run_pybamm_reference",
    "run_pybamm_reference_cycles",
    "TRPackConfig",
    "list_tr_presets",
    "tr_power_watts",
    "tr_preset_values",
    "uniform_tr_pack_config",
    "PackThermalParams",
    "neighbor_temperature_features",
    "CoupledPackResult",
    "run_coupled_pack",
]
